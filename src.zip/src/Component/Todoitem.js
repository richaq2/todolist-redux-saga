import React   from 'react';
import {deleteTodo} from '../redux/app.actions';
import { useDispatch } from 'react-redux';
import {Button} from 'antd';

const TodoItem = ({todo})=> {
    console.log("todo=>",todo)
    const dispatch = useDispatch();
return (
    <>
    <div className='mx-3 align-items-center'>
        
        <div>
            <div><h4>#{Math.trunc(todo.id*10)}&nbsp;{todo.name}</h4>
            <Button type='primary'
        onClick={()=> dispatch(deleteTodo({id:todo.id}))} 
        danger
        >
           Delete </Button>
            </div>
            
        
        </div>
        
    </div>
    </>
)
}

export default TodoItem;